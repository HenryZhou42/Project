package ca.nait.yzhou42.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.IntentFilter;
import android.telephony.TelephonyManager;
import android.content.ContentResolver;
import android.content.Context;
import java.lang.reflect.Method;
import java.util.Objects;

import android.content.Intent;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.Settings;
import android.provider.Settings.SettingNotFoundException;
import android.provider.Settings.System;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    private static final String TAG = "MainActivity";
    //Seek bar
    private SeekBar seekBar;
    //Brightness variable
    private int brightness;
    //Content reslover
    private ContentResolver contentResolver;
    //Window object
    private Window window;

    TextView textview;
    Button button;
    IntentFilter intentfilter;
    int deviceStatus;
    String currentBatteryStatus="Battery Info";
    int batteryLevel;

    Switch airSwitch, dataSwitch, wifiSwitch;


    TextView percentage;

    WifiManager wifiManager;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (android.os.Build.VERSION.SDK_INT > 9)
        {
            StrictMode.ThreadPolicy policy =
                    new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        //Instantiate seekBar
        seekBar = (SeekBar) findViewById(R.id.seekBar);

        percentage = (TextView) findViewById(R.id.brightnessPercentage);

        airSwitch = (Switch) findViewById(R.id.airSwitch);

        dataSwitch = (Switch) findViewById(R.id.dataSwitch);

        wifiSwitch = (Switch) findViewById(R.id.wifiSwitch);

        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        contentResolver = getContentResolver();

        window = getWindow();

        seekBar.setMax(255);

        seekBar.setKeyProgressIncrement(1);

        button = (Button)findViewById(R.id.buttonBattery);
        textview = (TextView)findViewById(R.id.textViewBatteryStatus);

        intentfilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);

        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                MainActivity.this.registerReceiver(broadcastreceiver,intentfilter);

            }
        });

        try{
            //Get the current system brightness
            brightness = System.getInt(contentResolver, System.SCREEN_BRIGHTNESS);
        }
        catch (SettingNotFoundException e)
        {
            //Error
            Log.e("Error", "Can`t access system brightness");
            e.printStackTrace();
        }

        seekBar.setProgress(brightness);

        seekBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
            {
                if(progress<=54)
                {
                    brightness = 54;
                }else
                    {
                       brightness = progress;
                    }
                float percent = (brightness/(float)255)*100;
                percentage.setText((int)percent + " %");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar)
            {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar)
            {
                System.putInt(contentResolver, System.SCREEN_BRIGHTNESS, brightness);
                LayoutParams layoutParams = window.getAttributes();
                layoutParams.screenBrightness = brightness / (float)255;
                window.setAttributes(layoutParams);
            }
        });

        airSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String airMode, data, wifi;
                if(airSwitch.isChecked())
                {
                    airMode = airSwitch.getTextOn().toString();

                    //Toast.makeText(getApplicationContext(), "Airplane mode is " + airMode, Toast.LENGTH_LONG).show();
                }
                else
                {
                    airMode = airSwitch.getTextOff().toString();

                   // Toast.makeText(getApplicationContext(), "Airplane mode is " + airMode, Toast.LENGTH_LONG).show();
                }

                Toast.makeText(getApplicationContext(), "Airplane mode is " + airMode, Toast.LENGTH_LONG).show();

            }
        });

        wifiSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String airMode, data, wifi;

                if(wifiSwitch.isChecked())
                {
                    wifi = wifiSwitch.getTextOn().toString();
                    wifiManager.setWifiEnabled(true);
                    //Toast.makeText(getApplicationContext(), "Wifi is " + wifi, Toast.LENGTH_LONG).show();
                }
                else
                {
                    wifi = wifiSwitch.getTextOff().toString();
                    wifiManager.setWifiEnabled(false);
                    //Toast.makeText(getApplicationContext(), "Wifi is " + wifi, Toast.LENGTH_LONG).show();
                }

                Toast.makeText(getApplicationContext(), "Wifi is " + wifi, Toast.LENGTH_LONG).show();

            }
        });

        dataSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String airMode, data, wifi;
                if(dataSwitch.isChecked())
                {
                    data = dataSwitch.getTextOn().toString();
                    setMobileDataState(true);
                    //Toast.makeText(getApplicationContext(), "Data is " + data, Toast.LENGTH_LONG).show();
                }
                else
                {
                    data = dataSwitch.getTextOff().toString();
                    setMobileDataState(false);
                    //Toast.makeText(getApplicationContext(), "Data is " + data, Toast.LENGTH_LONG).show();
                }

                Toast.makeText(getApplicationContext(), "Data is " + data, Toast.LENGTH_LONG).show();
            }
        });
    }

    public void setMobileDataState(boolean mobileDataEnabled)
    {
        try
        {
            TelephonyManager telephonyService = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

            Method setMobileDataEnabledMethod = telephonyService.getClass().getDeclaredMethod("setDataEnabled", boolean.class);

            if (null != setMobileDataEnabledMethod)
            {
                setMobileDataEnabledMethod.invoke(telephonyService, mobileDataEnabled);
            }
        }
        catch (Exception ex)
        {
            Log.e(TAG, "Error setting mobile data state", ex);
        }
    }

    public void onRadioButtonClicked(View view)
    {
        boolean checked = ((RadioButton) view).isChecked();

        switch (view.getId())
        {
            case R.id.radio_day:
                if (checked)
                {
                    seekBar.setProgress(156);
                    System.putInt(contentResolver, System.SCREEN_BRIGHTNESS, 156);
                }
                break;
            case R.id.radio_night:
                if (checked)
                {
                    seekBar.setProgress(56);
                    System.putInt(contentResolver, System.SCREEN_BRIGHTNESS, 56);
                }
                break;
        }
    }

    private BroadcastReceiver broadcastreceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            deviceStatus = intent.getIntExtra(BatteryManager.EXTRA_STATUS,-1);
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int batteryLevel=(int)(((float)level / (float)scale) * 100.0f);

            if(deviceStatus == BatteryManager.BATTERY_STATUS_CHARGING){

                textview.setText(currentBatteryStatus+" : Charging at "+batteryLevel+" %");

            }

            if(deviceStatus == BatteryManager.BATTERY_STATUS_DISCHARGING){

                textview.setText(currentBatteryStatus+" : Discharging at "+batteryLevel+" %");

            }

            if (deviceStatus == BatteryManager.BATTERY_STATUS_FULL){

                textview.setText(currentBatteryStatus+": Battery Full at "+batteryLevel+" %");

            }

            if(deviceStatus == BatteryManager.BATTERY_STATUS_UNKNOWN){

                textview.setText(currentBatteryStatus+" : Unknown at "+batteryLevel+" %");
            }


            if (deviceStatus == BatteryManager.BATTERY_STATUS_NOT_CHARGING){

                textview.setText(currentBatteryStatus+" = Not Charging at "+batteryLevel+" %");

            }

        }
    };


}